<h2 style="text-align:center"><b> SPP Ujikom </b></h2>
    <h3 style="text-align:center">Tanda Bukti Pembayaran</h3>
    <br>
    <p><b>Nama : <?php echo e($siswa->nama); ?></b> </p>
    <p><b>Kelas : <?php echo e($siswa->kelas->nama_kelas); ?> - <?php echo e($siswa->kelas->kompetensi_keahlian); ?></b></p>
    <table class="table table-bordered" style="border: 1px solid black; width: 100%">
        <tr style="border: 1px solid black;" class="text-center">
            <th>Nisn</th>
            <th>Tagihan</th>
            <th>Tanggal Dibayar</th>
            <th>Jumlah</th>
            <th>Keterangan</th>
        </tr>
        <?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td style="width:20px;">
                <?php echo e($item->nisn); ?>

            </td>
            <td style="width:30px;">
                SPP Tahun Ajaran <?php echo e($item->tahun_dibayar); ?>

            </td>
            <td style="width:20px; text-align: center;">
                <?php echo e($item->tgl_bayar); ?>

            </td>
            <td style="width:20px;">
                IDR. <?php echo e(format_idr($item->jumlah_bayar)); ?>

            </td>
            <td style="width:20px; text-align: center;">
                <?php echo e($item->keterangan); ?>

            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <style>
    @media  print {
        tr.gray {
            background-color: #ececec !important;
            -webkit-print-color-adjust: exact; 
        }
        th {
            background-color: #dadada !important;
            -webkit-print-color-adjust: exact; 
        }
    }
    </style>
    <script>
        window.print()
        
        window.onafterprint = function(){
            window.close()
        }
    </script><?php /**PATH D:\1. Sekolah\Kelas 4 - PKL\UJIKOM\Aplikasi\sppujikom\resources\views/transaksi/print.blade.php ENDPATH**/ ?>