<?php $__env->startSection('page-name','Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1 class="page-title">
            Dashboard
        </h1>
    </div>
    <div class="row">
        <div class="col-6 col-sm-3 col-lg-3">
            <div class="card">
                <div class="card-body p-3 text-center">
                    <div class="h1 m-0">IDR</div>
                    <div class="text-muted mb-4">Total Uang SPP</div>
                </div>
            </div>
        </div>
        <div class="col-6 col-sm-3 col-lg-3">
            <div class="card">
                <div class="card-body p-3 text-center">
                    <div class="h1 m-0">0</div>
                    <div class="text-muted mb-4">Siswa</div>
                </div>
            </div>
        </div>
        <div class="col-6 col-sm-3 col-lg-3">
            <div class="card">
                <div class="card-body p-3 text-center">
                    <div class="h1 m-0">0</div>
                    <div class="text-muted mb-4">Kelas</div>
                </div>
            </div>
        </div>
        <div class="col-6 col-sm-3 col-lg-3">
            <div class="card">
                <div class="card-body p-3 text-center">
                    <div class="h1 m-0">0</div>
                    <div class="text-muted mb-4">Petugas</div>
                </div>
            </div>
        </div>
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Laporan Harian</h3>
                    <div class="card-options">
                        <input
                            class="form-control mr-2"
                            type="text"
                            name="dates"
                            style="max-width: 200px"
                            data-toggle="datepicker"
                            autocomplete="off"
                            id="date"
                        />
                        <button
                            id="btn-cetak-spp"
                            class="btn btn-primary mr-1 text-nowrap"
                            value="#"
                        >
                            <i class="fe fe-download text-white"></i>
                        </button>
                        <button
                            id="btn-export-spp"
                            class="btn btn-primary text-nowrap"
                        >
                            <i
                                class="fe fe-external-link text-white"
                            ></i>
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <table
                        class="table card-table table-responsive table-hover table-vcenter text-nowrap title"
                        id="print"
                    >
                        <thead>
                            <tr>
                                <th>Tanggal</th>
                                <th>Nama</th>
                                <th>Pembayaran</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>
                                    <b>Total</b>
                                </td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\1. Sekolah\Kelas 4 - PKL\UJIKOM\Aplikasi\sppujikom\resources\views/dashboard/index.blade.php ENDPATH**/ ?>