<table>
    <thead>
    <tr>
        <th>Nisn</th>
        <th>Nis</th>
        <th>Nama Siswa</th>
        <th>Kelas</th>
        <th>Kompetensi Keahlian</th>
        <th>Jenis Kelamin</th>
        <th>No.telp</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item->nisn); ?></td>
            <td><?php echo e($item->nis); ?></td>
            <td><?php echo e($item->nama); ?></td>
            <td>
                <?php echo e($item->kelas->nama_kelas); ?>

            </td>
            <td>
                <?php echo e($item->kelas->kompetensi_keahlian); ?>

            </td>
            <td>
                <?php echo e($item->jenis_kelamin); ?>

            </td>
            <td>
                <?php echo e($item->no_telp); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\1. Sekolah\Kelas 4 - PKL\UJIKOM\Aplikasi\sppujikom\resources\views/siswa/export.blade.php ENDPATH**/ ?>