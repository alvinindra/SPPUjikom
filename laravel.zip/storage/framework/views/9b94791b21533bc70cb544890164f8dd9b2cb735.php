<div class="header collapse d-lg-flex p-0" id="headerMenuCollapse">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg order-lg-first">
                <ul class="nav nav-tabs border-0 flex-column flex-lg-row">
                    <li class="nav-item">
                        <a href="<?php echo e(route('users.dashboard')); ?>" class="nav-link <?php echo e(set_active(['users.*'], 'active')); ?>">
                            <i class="fe fe-home"></i>Dashboard
                        </a>
                    </li>
                    <?php $role = Auth::user()->level; ?>
                    <?php if($role == "administrator"): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('transaksi.index')); ?>" class="nav-link <?php echo e(set_active(['transaksi.*'], 'active')); ?>">
                                <i class="fe fe-repeat"></i>Transaksi SPP
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('spp.manage')); ?>" class="nav-link <?php echo e(set_active(['spp.*'], 'active')); ?>">
                                <i class="fe fe-repeat"></i>SPP
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('siswa.manage')); ?>" class="nav-link <?php echo e(set_active(['siswa.*'], 'active')); ?>">
                                <i class="fe fe-users"></i>Siswa
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('kelas.manage')); ?>" class="nav-link <?php echo e(set_active(['kelas.*'], 'active')); ?>">
                                <i class="fe fe-box"></i>Kelas
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.manage.users')); ?>" class="nav-link <?php echo e(set_active(['admin.*'], 'active')); ?>">
                                <i class="fe fe-box"></i>Manage Users
                            </a>
                        </li>
                    <?php endif; ?>
                    
                    <?php if($role == "petugas"): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('transaksi.index')); ?>" class="nav-link <?php echo e(set_active(['transaksi.*'], 'active')); ?>">
                                <i class="fe fe-repeat"></i>Transaksi SPP
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('siswa.manage')); ?>" class="nav-link <?php echo e(set_active(['siswa.*'], 'active')); ?>">
                                <i class="fe fe-users"></i>Siswa
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\1. Sekolah\Kelas 4 - PKL\UJIKOM\Aplikasi\sppujikom\resources\views/shared/navbar.blade.php ENDPATH**/ ?>