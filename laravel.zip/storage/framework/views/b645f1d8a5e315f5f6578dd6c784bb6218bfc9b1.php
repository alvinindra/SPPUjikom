<?php $__env->startSection('page-name', (isset($spp) ? 'Ubah SPP' : 'SPP Baru')); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-8 col-12">
            <form action="<?php echo e((isset($spp) ? route('spp.update', $spp->id_spp) : route('spp.create'))); ?>" method="post" class="card">
                <div class="card-header">
                    <h3 class="card-title"><?php echo $__env->yieldContent('page-name'); ?></h3>
                </div>
                <div class="card-body">
                    <?php if(session()->has('msg')): ?>
                        <div class="card-alert alert alert-<?php echo e(session()->get('type')); ?> mb-5" id="message" style="border-radius: 0px !important">
                            <?php if(session()->get('type') == 'success'): ?>
                                <i class="fe fe-check mr-2" aria-hidden="true"></i>
                            <?php else: ?>
                                <i class="fe fe-alert-triangle mr-2" aria-hidden="true"></i> 
                            <?php endif; ?>
                                <?php echo e(session()->get('msg')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($error); ?><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-12">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label class="form-label">Tahun<span class="form-required">*</span></label>
                                <input type="text" class="form-control" name="tahun" placeholder="Tahun" pattern="\d*" maxlength="4" value="<?php echo e(isset($spp) ? $spp->tahun : old('tahun')); ?>" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Nominal<span class="form-required">*</span></label>
                                <input id="inputNominal" type="text" class="form-control" name="nominal" placeholder="Nominal" pattern="\d*" maxlength="10" value="<?php echo e(isset($spp) ? $spp->nominal : old('nominal')); ?>" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Perbulan<span class="form-required">*</span></label>
                                <input id="outputPerbulan" type="text" class="form-control" name="perbulan" placeholder="Perbulan" pattern="\d*" maxlength="4" value="<?php echo e(isset($spp) ? $spp->total_perbulan : old('total_perbulan')); ?>" readonly>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer text-right">
                    <div class="d-flex">
                        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-light">Batal</a>
                        <button type="submit" class="btn btn-primary ml-auto">Simpan</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    require(['jquery', 'selectize'], function ($, selectize) {
        $(document).ready(function () {
            $('#select-beast').selectize({});
        });

        const input = document.querySelector('#inputNominal');
        const output = document.querySelector('#outputPerbulan');

        input.addEventListener('input', divide);
        input.addEventListener('change', divide);
        
        function divide() {
            const divided = input.value / 12;
            output.value = divided;
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\1. Sekolah\Kelas 4 - PKL\UJIKOM\Aplikasi\sppujikom\resources\views//admin/form_spp.blade.php ENDPATH**/ ?>