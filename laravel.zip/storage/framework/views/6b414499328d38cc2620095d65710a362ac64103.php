<?php $__env->startSection('page-name', (isset($siswa) ? 'Ubah Siswa' : 'Siswa Baru')); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-8 col-12">
            <form action="<?php echo e((isset($siswa) ? route('siswa.update', $siswa->id) : route('siswa.create'))); ?>" method="post" class="card">
                <div class="card-header">
                    <h3 class="card-title"><?php echo $__env->yieldContent('page-name'); ?></h3>
                </div>
                <div class="card-body">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($error); ?><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-12">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label class="form-label">Kelas<span class="form-required">*</span></label>
                                <select id="select-beast" class="form-control custom-select" name="id_kelas" required>
                                    <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id_kelas); ?>" <?php echo e(isset($siswa) ? ($item->id_kelas == $siswa->id_kelas ? 'selected' : '') : ''); ?>><?php echo e($item->nama_kelas); ?> - <?php echo e($item->kompetensi_keahlian); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Nisn<span class="form-required">*</span></label>
                                <input type="text" class="form-control" maxlength="10" name="nisn" placeholder="NISN Siswa" value="<?php echo e(isset($siswa) ? $siswa->nisn : old('nisn')); ?>" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Nis<span class="form-required">*Nis adalah username</span></label>
                                <input type="text" class="form-control" maxlength="9" name="nis" placeholder="NIS Siswa" value="<?php echo e(isset($siswa) ? $siswa->nis : old('nis')); ?>" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Password<span class="form-required">*</span></label>
                                <input type="password" class="form-control" name="password" placeholder="Password Siswa" value="" <?php echo e(isset($akunSiswa) ? '' : 'required'); ?>>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Konfirmasi Password<span class="form-required">*</span></label>
                                <input type="password" class="form-control" name="password_confirmation" placeholder="Konfirmasi Password Siswa" value="" <?php echo e(isset($akunSiswa) ? '' : 'required'); ?>>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Nama<span class="form-required">*</span></label>
                                <input type="text" class="form-control" name="nama" placeholder="Nama Lengkap" value="<?php echo e(isset($siswa) ? $siswa->nama : old('nama')); ?>" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Email<span class="form-required">*</span></label>
                                <input type="email" class="form-control" name="email" placeholder="Email" value="<?php echo e(isset($akunSiswa) ? $akunSiswa->email : old('email')); ?>" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Jenis Kelamin</label>
                                <select id="select-beast" class="form-control custom-select" name="jenis_kelamin">
                                    <option value="Laki-laki" <?php echo e(isset($siswa) ? ($siswa->jenis_kelamin == 'Laki-laki' ? 'selected' : '') : ''); ?>>Laki - Laki</option>
                                    <option value="Perempuan" <?php echo e(isset($siswa) ? ($siswa->jenis_kelamin == 'Perempuan' ? 'selected' : '') : ''); ?>>Perempuan</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Alamat</label>
                                <textarea class="form-control" name="alamat"><?php echo e(isset($siswa) ? $siswa->alamat : old('alamat')); ?></textarea>
                            </div>
                            <div class="form-group">
                                <label class="form-label">No. Telp.</label>
                                <input type="text" class="form-control" name="no_telp" maxlength="13" placeholder="Nomor Telp. Lengkap" value="<?php echo e(isset($siswa) ? $siswa->no_telp : old('no_telp')); ?>">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Spp<span class="form-required">*</span></label>
                                <select id="select-beast" class="form-control custom-select" name="id_spp" required>
                                    <?php $__currentLoopData = $spp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id_spp); ?>" <?php echo e(isset($siswa) ? ($item->id_spp == $siswa->id_spp ? 'selected' : '') : ''); ?>>SPP Tahun Ajaran <?php echo e($item->tahun); ?> - <?php echo e(format_idr($item->nominal)); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer text-right">
                    <div class="d-flex">
                        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-link">Batal</a>
                        <button type="submit" class="btn btn-primary ml-auto">Simpan</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    require(['jquery', 'selectize','datepicker'], function ($, selectize) {
        $(document).ready(function () {

            $('.custom-select').selectize({});
            $('[data-toggle="datepicker"]').datepicker({
                format: 'yyyy-MM-dd'
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\1. Sekolah\Kelas 4 - PKL\UJIKOM\Aplikasi\sppujikom\resources\views//admin/form_siswa.blade.php ENDPATH**/ ?>