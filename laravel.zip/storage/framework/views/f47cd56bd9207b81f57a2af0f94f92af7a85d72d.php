<?php $__env->startSection('page-name','Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 col-md-4">
        <div class="card">
            <div class="card-body">
                <div class="table-bordered table-responsive">
                    <table class="table card-table text-nowrap">
                        <tr>
                            <td class="font-weight-bold">Nisn</td>
                            <td><?php echo e($siswa->nisn); ?></td>
                        </tr>
                        <tr>
                            <td class="font-weight-bold">Nis</td>
                            <td><?php echo e($siswa->nis); ?></td>
                        </tr>
                        <tr>
                            <td class="font-weight-bold">Nama</td>
                            <td><?php echo e($siswa->nama); ?></td>
                        </tr>
                        <tr>
                            <td class="font-weight-bold">Kelas</td>
                            <td><?php echo e($siswa->kelas->nama_kelas); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12 col-md-8 mb-5">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Tagihan SPP</h3>
                <div class="card-options">
                    <button id="btn-cetak-spp" class="btn btn-primary mr-1 text-nowrap"
                        value="<?php echo e($siswa->id); ?>">Cetak</button>
                    <a id="btn-export-spp" class="btn btn-primary text-nowrap"
                        href="<?php echo e(route('transaksi.export',$siswa->id )); ?>">Export</a>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive table-bordered">
                    <table class="table card-table table-hover text-wrap">
                        <thead>
                            <tr>
                                <th class="w-1">No.</th>
                                <th>NISN</th>
                                <th>Bulan Dibayar</th>
                                <th>Tahun Ajaran</th>
                                <th>Jumlah Bayar</th>
                                <th>Tanggal Dibayar</th>
                                <th>Keterangan</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><span class="text-muted"><?php echo e($index+1); ?></span></td>
                                <td>
                                    <?php echo e($item->nisn); ?>

                                </td>
                                <td>
                                    <?php echo e($item->bulan_dibayar); ?>

                                </td>
                                <td>
                                    <?php echo e($item->spp->tahun); ?>

                                </td>
                                <td>
                                    Rp.<?php echo e(format_idr($item->jumlah_bayar)); ?>

                                </td>
                                <td>
                                    <?php echo e($item->tgl_bayar); ?>

                                </td>
                                <td class="text-center">
                                    <?php if( $item->keterangan == 'Lunas'): ?>
                                        <span class="tag tag-green">Lunas</span>
                                    <?php else: ?>
                                        <span class="tag tag-red">Belum Lunas</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        require(['jquery', 'moment'], function ($, moment) {
            $(document).ready(function () {
                $('#btn-cetak-spp').on('click', function(){
                    var form = document.createElement("form");
                    form.setAttribute("style", "display: none");
                    form.setAttribute("method", "post");
                    form.setAttribute("action", "<?php echo e(route('transaksi.cetak', $siswa->id)); ?>");
                    form.setAttribute("target", "_blank");
                    
                    var token = document.createElement("input");
                    token.setAttribute("name", "_token");
                    token.setAttribute("value", "<?php echo e(csrf_token()); ?>");
                    
                    var dateForm = document.createElement("input");
                    dateForm.setAttribute("name", "date");
                    dateForm.setAttribute("value", $('#date').val());
    
                    form.appendChild(token);
                    form.appendChild(dateForm);
                    document.body.appendChild(form);
                    form.submit();
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\1. Sekolah\Kelas 4 - PKL\UJIKOM\Aplikasi\sppujikom\resources\views//siswa/dashboard.blade.php ENDPATH**/ ?>