<?php $__env->startSection('page-name', (isset($user) ? 'Ubah Pengguna' : 'Pengguna Baru')); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-8">
            <form action="<?php echo e((isset($user) ? route('admin.edit.user', $user->id) : route('admin.create.user'))); ?>" method="post" class="card">
                <div class="card-header">
                    <h3 class="card-title"><?php echo $__env->yieldContent('page-name'); ?></h3>
                </div>
                <div class="card-body">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($error); ?><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-12">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label class="form-label">Nama</label>
                                <input type="text" class="form-control" name="nama_users" placeholder="Nama" value="<?php echo e(isset($user) ? $user->name : old('name')); ?>" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Username</label>
                                <input type="text" class="form-control" name="username" placeholder="Username" value="<?php echo e(isset($user) ? $user->username : old('username')); ?>" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Email</label>
                                <input type="text" class="form-control" name="email" placeholder="Email" value="<?php echo e(isset($user) ? $user->email : old('email')); ?>" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Password</label>
                                <input type="password" class="form-control" name="password" value="" <?php echo e(isset($user) ? '' : 'required'); ?>>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Konfirmasi Password</label>
                                <input type="password" class="form-control" name="password_confirmation" value="" <?php echo e(isset($user) ? '' : 'required'); ?>>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Status</label>
                                <select id="select-beast" class="form-control custom-select" name="level">
                                    <option value="administrator" <?php echo e(isset($user) ? ($user->role == 'administrator' ? 'selected' : '') : ''); ?>>Administrator</option>
                                    <option value="petugas" <?php echo e(isset($user) ? ($user->role == 'petugas' ? 'selected' : '') : ''); ?>>Petugas</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer text-right">
                    <div class="d-flex">
                        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-light">Batal</a>
                        <button type="submit" class="btn btn-primary ml-auto">Simpan</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    require(['jquery', 'selectize'], function ($, selectize) {
        $(document).ready(function () {
            $('#select-beast').selectize({});
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\1. Sekolah\Kelas 4 - PKL\UJIKOM\Aplikasi\sppujikom\resources\views//admin/add_users.blade.php ENDPATH**/ ?>