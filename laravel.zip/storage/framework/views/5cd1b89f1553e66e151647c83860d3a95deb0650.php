<?php $__env->startSection('page-name','Siswa'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 col-md-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title"><?php echo $__env->yieldContent('page-name'); ?></h3>
            </div>
            <div class="card-body">
                <table class="table card-table table-bordered text-nowrap">
                    <tr>
                        <td class="font-weight-bold">Nisn</td>
                        <td><?php echo e($siswa->nisn); ?></td>
                    </tr>
                    <tr>
                        <td class="font-weight-bold">Nis</td>
                        <td><?php echo e($siswa->nis); ?></td>
                    </tr>
                    <tr>
                        <td class="font-weight-bold">Nama</td>
                        <td><?php echo e($siswa->nama); ?></td>
                    </tr>
                    <tr>
                        <td class="font-weight-bold">Kelas</td>
                        <td><?php echo e($siswa->kelas->nama_kelas); ?></td>
                    </tr>
                    <tr>
                        <td class="font-weight-bold">Jenis Kelamin</td>
                        <td><?php echo e($siswa->jenis_kelamin); ?></td>
                    </tr>
                    <tr>
                        <td class="font-weight-bold">Alamat</td>
                        <td><?php echo e($siswa->alamat); ?></td>
                    </tr>
                    <tr>
                        <td class="font-weight-bold">No.Telp</td>
                        <td><?php echo e($siswa->no_telp); ?></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
    <div class="col-12 col-md-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Tagihan SPP</h3>
                <div class="card-options">
                    <button id="btn-cetak-spp" class="btn btn-primary mr-1 text-nowrap"
                        value="<?php echo e($siswa->id); ?>">Cetak</button>
                    <a id="btn-export-spp" class="btn btn-primary text-nowrap"
                        href="<?php echo e(route('transaksi.export',$siswa->id )); ?>">Export</a>
                </div>
            </div>
            <div class="card-body">
                <table class="table card-table table-hover table-vcenter text-wrap">
                    <thead>
                        <tr>
                            <th class="w-1">No.</th>
                            <th>NISN</th>
                            <th>Bulan Dibayar</th>
                            <th>Tahun Ajaran</th>
                            <th>Jumlah Bayar</th>
                            <th>Tanggal Dibayar</th>
                            <th>Keterangan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $siswa->pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><span class="text-muted"><?php echo e($index+1); ?></span></td>
                                <td>
                                    <?php echo e($item->nisn); ?>

                                </td>
                                <td>
                                    <?php echo e($item->bulan_dibayar); ?>

                                </td>
                                <td>
                                    <?php echo e($item->spp->tahun); ?>

                                </td>
                                <td>
                                    Rp.<?php echo e(format_idr($item->jumlah_bayar)); ?>

                                </td>
                                <td>
                                    <?php echo e($item->tgl_bayar); ?>

                                </td>
                                <td class="text-center">
                                    <?php if( $item->keterangan == 'Lunas'): ?>
                                        <span class="tag tag-green">Lunas</span>
                                    <?php else: ?>
                                        <span class="tag tag-red">Belum Lunas</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/daterangepicker.css')); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    require(['jquery', 'moment'], function ($, moment) {

    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\1. Sekolah\Kelas 4 - PKL\UJIKOM\Aplikasi\sppujikom\resources\views//admin/show_siswa.blade.php ENDPATH**/ ?>