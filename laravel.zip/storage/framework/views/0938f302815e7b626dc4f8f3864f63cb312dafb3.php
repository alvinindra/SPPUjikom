<?php $__env->startSection('page-name','Kelas'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1 class="page-title">
            <?php echo $__env->yieldContent('page-name'); ?>
        </h1>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title"><?php echo $__env->yieldContent('page-name'); ?></h3>
                    <a href="<?php echo e(route('kelas.create')); ?>" class="btn btn-outline-primary btn-sm ml-5">Tambah Kelas</a>
                    
                </div>
                <?php if(session()->has('msg')): ?>
                <div class="card-alert alert alert-<?php echo e(session()->get('type')); ?>" id="message" style="border-radius: 0px !important">
                    <?php if(session()->get('type') == 'success'): ?>
                        <i class="fe fe-check mr-2" aria-hidden="true"></i>
                    <?php else: ?>
                        <i class="fe fe-alert-triangle mr-2" aria-hidden="true"></i> 
                    <?php endif; ?>
                        <?php echo e(session()->get('msg')); ?>

                </div>
                <?php endif; ?>
                <div class="table-responsive">
                    <table id="tb_list_datakelas" class="table card-table table-vcenter text-nowrap datatable">
                        <thead>
                        <tr>
                            <th class="w-1">No.</th>
                            <th>Nama Kelas</th>
                            <th>Kompetensi Keahlian</th>
                            <th>Tanggal Dibuat</th>
                            <th class="text-center">Aksi</th> 
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><span class="text-muted"><?php echo e($index+1); ?></span></td>
                                <td>
                                    <?php echo e($item->nama_kelas); ?>

                                </td>
                                <td>
                                    <?php echo e($item->kompetensi_keahlian); ?>

                                </td>
                                <td>
                                   <?php echo e($item->created_at); ?>

                                </td>
                                <td class="text-center">
                                    <a class="icon" href="<?php echo e(route('kelas.edit', $item->id_kelas)); ?>" title="Edit Kelas">
                                        <i class="fe fe-edit"></i>
                                    </a>
                                    <a class="icon btn-delete" href="void:javascript(0)" data-id="<?php echo e($item->id_kelas); ?>" title="Delete Kelas">
                                        <i class="fe fe-trash"></i>
                                    </a>
                                    <form action="<?php echo e(route('kelas.delete', $item->id_kelas)); ?>" method="POST" id="form-<?php echo e($item->id_kelas); ?>">
                                        <?php echo csrf_field(); ?> 
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('/plugins/datatables/plugin.js')); ?>"></script>
<script>
    require(['datatables','jquery','sweetalert'], function(datatable, $) {
        $(document).ready(function () {
            $(document).on('click','.btn-delete', function(){
                formid = $(this).attr('data-id');
                swal({
                    title: 'Anda yakin ingin menghapus?',
                    text: 'Kelas yang dihapus tidak dapat dikembalikan',
                    dangerMode: true,
                    buttons: {
                        cancel: true,
                        confirm: true,
                    },
                }).then((result) => {
                    if (result) {
                        $('#form-' + formid).submit();
                    }
                })
            })
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\1. Sekolah\Kelas 4 - PKL\UJIKOM\Aplikasi\sppujikom\resources\views//admin/manage_kelas.blade.php ENDPATH**/ ?>